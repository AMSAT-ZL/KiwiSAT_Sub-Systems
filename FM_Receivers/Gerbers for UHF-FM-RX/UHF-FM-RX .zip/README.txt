UHF-FM-RX PCB Files:

This data pack contains 10 files including this one.

The files are:

UHF-FM-RX.DRL	NC Drill file in ASCII format

UHF-FM-RX.GD1	Fabrication Drawing file

UHF-FM-RX.GTL	Layer 1 file

UHF-FM-RX.GBL	Layer 2 file

UHF-FM-RX.DRR	Drill file report

UHF-FM-RX.GTS	Solder Resist Layer 1 file

UHF-FM-RX.GTO	Silk Screen Layer 1 file

UHF-FM-RX.GBS	Solder Resist Layer 2 file

UHF-FM-RX.GTO	Silk Screen Layer 2 file


Contact person for queries:

Terry Osborne
46 Hicks Crescent
Waikanae Beach
Kapiti 6010
New Zealand 
email: osbornes@paradise.net.nz  